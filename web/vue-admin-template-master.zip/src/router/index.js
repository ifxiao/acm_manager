import Vue from 'vue'
import Router from 'vue-router'

// in development-env not use lazy-loading, because lazy-loading too many pages will cause webpack hot update too slow. so only in production use lazy-loading;
// detail: https://panjiachen.github.io/vue-element-admin-site/#/lazy-loading

Vue.use(Router)

/* Layout */
import Layout from '../views/layout/Layout'
import tableRouter from './modules/table'

/**
* hidden: true                   if `hidden:true` will not show in the sidebar(default is false)
* alwaysShow: true               if set true, will always show the root menu, whatever its child routes length
*                                if not set alwaysShow, only more than one route under the children
*                                it will becomes nested mode, otherwise not show the root menu
* redirect: noredirect           if `redirect:noredirect` will no redirect in the breadcrumb
* name:'router-name'             the name is used by <keep-alive> (must set!!!)
* meta : {
    title: 'title'               the name show in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar,
  }
**/
export const constantRouterMap = [
  { path: '/login', component: () => import('@/views/login/index'), hidden: true },
  { path: '/404', component: () => import('@/views/404'), hidden: true },

  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    name: 'Dashboard',
    hidden: true,
    children: [{
      path: 'dashboard',
      component: () => import('@/views/dashboard/index')
    }]
  },
  tableRouter,
  // {
  //   path: '/example',
  //   component: Layout,
  //   redirect: '/example/table',
  //   name: 'Example',
  //   meta: { title: 'Example', icon: 'example' },
  //   children: [
  //     {
  //       path: 'table',
  //       name: 'Table',
  //       component: () => import('@/views/table/index'),
  //       meta: { title: 'Table', icon: 'table' }
  //     },
  //     {
  //       path: 'tree',
  //       name: 'Tree',
  //       component: () => import('@/views/tree/index'),
  //       meta: { title: 'Tree', icon: 'tree' }
  //     },

  //   ]
  // },
  {
    path: '/member',
    component: Layout,
    redirect:"/member/table",
    name: '成员管理',
    meta: { title: '成员管理', icon: 'example' },
    children: [
      {
        path: 'table',
        name: '成员列表',
        component: () => import('@/views/acm/member/list'),
        meta: { title: '成员列表', icon: '' }
      },
      {
        path: 'edit/:user_id',
        name: '编辑成员',
        component: () => import('@/views/acm/member/save'),
        meta: { title: '编辑成员', noCache:true},
        hidden: true
      },
      {
        path: 'add',
        name: '添加成员',  
        component: () => import('@/views/acm/member/save'),
        meta: { title: '添加成员', icon: 'tree' }
      },
      // {
      //   path: 'test',
      //   name: 'test',
      //   component: () => import('@/views/acm/member/test'),
      //   meta: { title: 'test', icon: '' }
      // },
    ]
  },
  {
    path: '/contest',
    component: Layout,
    redirect:"/member/balloon",
    name: '比赛管理',
    meta: { title: '比赛管理', icon: 'example' },
    children: [
      {
        path: 'balloon',
        name: '气球监控',
        component: () => import('@/views/acm/contest/balloon'),
        meta: { title: '气球监控', icon: '' }
      }
      // {
      //   path: 'test',
      //   name: 'test',
      //   component: () => import('@/views/acm/member/test'),
      //   meta: { title: 'test', icon: '' }
      // },
    ]
  },
  {
    path: '/submit',
    component: Layout,
    redirect:"/submit/submit_list",
    name: '训练监控',
    meta: { title: '训练监控', icon: 'example' },
    children: [
      {
        path: 'submit_list',
        name: '刷题记录',
        component: () => import('@/views/acm/submit/submit_list'),
        meta: { title: '刷题记录', icon: '' }
      },
      {
        path: 'link_list',
        name: '关联账号',
        component: () => import('@/views/acm/submit/link_list'),
        meta: { title: '关联账号', icon: '' }
      },
      {
        path: 'link_edit',
        name: '添加关联账号',
        component: () => import('@/views/acm/submit/link_edit'),
        meta: { title: '添加关联账号' },
      },
      {
        path: 'link_edit/:link',
        name: '编辑关联账号',
        component: () => import('@/views/acm/submit/link_edit'),
        meta: { title: '编辑关联账号', noCache:true },
        hidden: true
      },
    ]
  },
  {
    path: '/team',
    component: Layout,
    redirect:"/team/team_list",
    name: '队伍管理',
    meta: { title: '队伍管理', icon: 'example' },
    children: [
      {
        path: 'team_list',
        name: '队伍列表',
        component: () => import('@/views/acm/team/team_list'),
        meta: { title: '队伍列表', icon: '' }
      },
      {
        path: 'add',
        name: '添加队伍',
        component: () => import('@/views/acm/team/team_edit'),
        meta: { title: '添加队伍' },
      },
      {
        path: 'edit/:team_id',
        name: '编辑队伍',
        component: () => import('@/views/acm/team/team_edit'),
        meta: { title: '编辑队伍', noCache:true },
        hidden: true
      },
    ]
  },
  // {
  //   path: '/form',
  //   component: Layout,
  //   children: [
  //     {
  //       path: 'index',
  //       name: 'Form',
  //       component: () => import('@/views/form/index'),
  //       meta: { title: 'Form', icon: 'form' }
  //     }
  //   ]
  // },

  {
    path: '/nested',
    component: Layout,
    redirect: '/nested/menu1',
    name: 'Nested',
    meta: {
      title: 'Nested',
      icon: 'nested'
    },
    children: [
      {
        path: 'menu1',
        component: () => import('@/views/nested/menu1/index'), // Parent router-view
        name: 'Menu1',
        meta: { title: 'Menu1' },
        children: [
          {
            path: 'menu1-1',
            component: () => import('@/views/nested/menu1/menu1-1'),
            name: 'Menu1-1',
            meta: { title: 'Menu1-1' }
          },
          {
            path: 'menu1-2',
            component: () => import('@/views/nested/menu1/menu1-2'),
            name: 'Menu1-2',
            meta: { title: 'Menu1-2' },
            children: [
              {
                path: 'menu1-2-1',
                component: () => import('@/views/nested/menu1/menu1-2/menu1-2-1'),
                name: 'Menu1-2-1',
                meta: { title: 'Menu1-2-1' }
              },
              {
                path: 'menu1-2-2',
                component: () => import('@/views/nested/menu1/menu1-2/menu1-2-2'),
                name: 'Menu1-2-2',
                meta: { title: 'Menu1-2-2' }
              }
            ]
          },
          
          {
            path: 'menu1-3',
            component: () => import('@/views/nested/menu1/menu1-3'),
            name: 'Menu1-3',
            meta: { title: 'Menu1-3' }
          }
        ]
      },
      {
        path: 'menu2',
        component: () => import('@/views/nested/menu2/index'),
        meta: { title: 'menu2' }
      }
    ]
  },

  {
    path: 'external-link',
    component: Layout,
    children: [
      {
        path: 'https://panjiachen.github.io/vue-element-admin-site/#/',
        meta: { title: 'External Link', icon: 'link' }
      }
    ]
  },

  { path: '*', redirect: '/404', hidden: true }
]

export default new Router({
  // mode: 'history', //后端支持可开
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})
